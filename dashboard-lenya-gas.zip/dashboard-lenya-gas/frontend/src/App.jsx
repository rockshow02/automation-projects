import { useState, useEffect } from "react";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell } from "recharts";

const API = "http://localhost:5000/api";

const fmt = (n) => new Intl.NumberFormat("id-ID").format(n || 0);
const fmtDate = (d) => new Date(d).toLocaleDateString("id-ID", { day: "2-digit", month: "short" });

const TABS = ["Dashboard", "Transaksi", "Hutang", "Input"];

export default function App() {
  const [tab, setTab] = useState("Dashboard");
  const [laporan, setLaporan] = useState(null);
  const [mingguan, setMingguan] = useState([]);
  const [hutang, setHutang] = useState([]);
  const [transaksi, setTransaksi] = useState([]);
  const [form, setForm] = useState({
    tanggal: new Date().toISOString().split("T")[0],
    ukuran_tabung: "3 Kg", jumlah: "", harga_jual: 19000,
    nama_pembeli: "", status_bayar: "Lunas", jumlah_dibayar: "", catatan: ""
  });
  const [stokForm, setStokForm] = useState({ tanggal: new Date().toISOString().split("T")[0], stok_awal: "" });
  const [msg, setMsg] = useState("");

  const load = async () => {
    const [l, m, h, t] = await Promise.all([
      fetch(`${API}/laporan/hari-ini`).then(r => r.json()),
      fetch(`${API}/laporan/mingguan`).then(r => r.json()),
      fetch(`${API}/hutang`).then(r => r.json()),
      fetch(`${API}/penjualan/semua`).then(r => r.json()),
    ]);
    setLaporan(l); setMingguan(m); setHutang(h); setTransaksi(t);
  };

  useEffect(() => { load(); }, []);

  const submitPenjualan = async (e) => {
    e.preventDefault();
    await fetch(`${API}/penjualan`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(form) });
    setMsg("✅ Transaksi tersimpan!");
    setTimeout(() => setMsg(""), 3000);
    load();
  };

  const submitStok = async (e) => {
    e.preventDefault();
    await fetch(`${API}/stok`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(stokForm) });
    setMsg("✅ Stok tersimpan!");
    setTimeout(() => setMsg(""), 3000);
    load();
  };

  const lunasin = async (id, total) => {
    await fetch(`${API}/penjualan/${id}/bayar`, { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ status_bayar: "Lunas", jumlah_dibayar: total }) });
    load();
  };

  const statusColor = (s) => s === "Lunas" ? "#00C896" : s === "Hutang" ? "#FF6B6B" : "#F4A261";

  return (
    <div style={{ minHeight: "100vh", background: "#0A0F1A", color: "#E8EDF5", fontFamily: "'DM Sans', sans-serif" }}>
      <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600&family=Space+Grotesk:wght@600;700&display=swap" rel="stylesheet" />

      {/* Header */}
      <div style={{ background: "#0F1624", borderBottom: "1px solid #1E2A3D", padding: "16px 24px", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
          <div style={{ width: 36, height: 36, background: "#00C896", borderRadius: 10, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 18 }}>⛽</div>
          <div>
            <div style={{ fontFamily: "'Space Grotesk', sans-serif", fontWeight: 700, fontSize: 16, color: "#fff" }}>Lenya Gas</div>
            <div style={{ fontSize: 12, color: "#5A7A9A" }}>Dashboard Penjualan</div>
          </div>
        </div>
        <div style={{ fontSize: 13, color: "#5A7A9A" }}>{new Date().toLocaleDateString("id-ID", { weekday: "long", day: "numeric", month: "long", year: "numeric" })}</div>
      </div>

      {/* Nav */}
      <div style={{ background: "#0F1624", padding: "0 24px", display: "flex", gap: 4, borderBottom: "1px solid #1E2A3D" }}>
        {TABS.map(t => (
          <button key={t} onClick={() => setTab(t)} style={{ padding: "12px 18px", background: "none", border: "none", color: tab === t ? "#00C896" : "#5A7A9A", fontFamily: "'DM Sans', sans-serif", fontWeight: 500, fontSize: 14, cursor: "pointer", borderBottom: tab === t ? "2px solid #00C896" : "2px solid transparent", transition: "all 0.2s" }}>{t}</button>
        ))}
      </div>

      <div style={{ padding: 24, maxWidth: 1100, margin: "0 auto" }}>

        {/* DASHBOARD */}
        {tab === "Dashboard" && laporan && (
          <div>
            {/* Stat cards */}
            <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(180px, 1fr))", gap: 12, marginBottom: 20 }}>
              {[
                { label: "Terjual Hari Ini", value: `${laporan.total_tabung} tabung`, icon: "🫙", accent: "#00C896" },
                { label: "Sisa Stok", value: `${laporan.sisa_stok} tabung`, icon: "📦", accent: laporan.sisa_stok <= 10 ? "#FF6B6B" : "#00C896" },
                { label: "Omset", value: `Rp ${fmt(laporan.total_omset)}`, icon: "💰", accent: "#F4A261" },
                { label: "Keuntungan Bersih", value: `Rp ${fmt(laporan.keuntungan_bersih)}`, icon: "📈", accent: "#00C896" },
                { label: "Belum Dibayar", value: `Rp ${fmt(laporan.belum_dibayar)}`, icon: "⏳", accent: laporan.belum_dibayar > 0 ? "#FF6B6B" : "#5A7A9A" },
              ].map(c => (
                <div key={c.label} style={{ background: "#0F1624", border: "1px solid #1E2A3D", borderRadius: 14, padding: "16px 18px" }}>
                  <div style={{ fontSize: 22, marginBottom: 8 }}>{c.icon}</div>
                  <div style={{ fontSize: 11, color: "#5A7A9A", marginBottom: 4, textTransform: "uppercase", letterSpacing: "0.05em" }}>{c.label}</div>
                  <div style={{ fontFamily: "'Space Grotesk', sans-serif", fontWeight: 700, fontSize: 18, color: c.accent }}>{c.value}</div>
                </div>
              ))}
            </div>

            {/* Keuangan detail */}
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12, marginBottom: 20 }}>
              <div style={{ background: "#0F1624", border: "1px solid #1E2A3D", borderRadius: 14, padding: 18 }}>
                <div style={{ fontWeight: 600, marginBottom: 14, color: "#fff" }}>Ringkasan Keuangan</div>
                {[
                  ["Modal", laporan.modal, "#5A7A9A"],
                  ["Keuntungan Kotor", laporan.keuntungan_kotor, "#F4A261"],
                  ["Dana Tabungan", laporan.dana_tabungan, "#A78BFA"],
                  ["Keuntungan Bersih", laporan.keuntungan_bersih, "#00C896"],
                ].map(([k, v, c]) => (
                  <div key={k} style={{ display: "flex", justifyContent: "space-between", padding: "8px 0", borderBottom: "1px solid #1E2A3D" }}>
                    <span style={{ fontSize: 14, color: "#8A9BAE" }}>{k}</span>
                    <span style={{ fontSize: 14, fontWeight: 600, color: c }}>Rp {fmt(v)}</span>
                  </div>
                ))}
              </div>

              <div style={{ background: "#0F1624", border: "1px solid #1E2A3D", borderRadius: 14, padding: 18 }}>
                <div style={{ fontWeight: 600, marginBottom: 14, color: "#fff" }}>Status Pembayaran</div>
                {[
                  ["Sudah Dibayar", laporan.sudah_dibayar, "#00C896"],
                  ["Belum Dibayar", laporan.belum_dibayar, "#FF6B6B"],
                ].map(([k, v, c]) => (
                  <div key={k} style={{ display: "flex", justifyContent: "space-between", padding: "8px 0", borderBottom: "1px solid #1E2A3D" }}>
                    <span style={{ fontSize: 14, color: "#8A9BAE" }}>{k}</span>
                    <span style={{ fontSize: 14, fontWeight: 600, color: c }}>Rp {fmt(v)}</span>
                  </div>
                ))}
                <div style={{ marginTop: 16, fontWeight: 600, marginBottom: 10, color: "#fff" }}>Stok Hari Ini</div>
                <div style={{ display: "flex", justifyContent: "space-between", padding: "8px 0", borderBottom: "1px solid #1E2A3D" }}>
                  <span style={{ fontSize: 14, color: "#8A9BAE" }}>Stok Awal</span>
                  <span style={{ fontSize: 14, fontWeight: 600, color: "#fff" }}>{laporan.stok_awal} tabung</span>
                </div>
                <div style={{ display: "flex", justifyContent: "space-between", padding: "8px 0" }}>
                  <span style={{ fontSize: 14, color: "#8A9BAE" }}>Sisa</span>
                  <span style={{ fontSize: 14, fontWeight: 600, color: laporan.sisa_stok <= 10 ? "#FF6B6B" : "#00C896" }}>{laporan.sisa_stok} tabung {laporan.sisa_stok <= 10 ? "⚠️" : "✅"}</span>
                </div>
              </div>
            </div>

            {/* Chart mingguan */}
            <div style={{ background: "#0F1624", border: "1px solid #1E2A3D", borderRadius: 14, padding: 18 }}>
              <div style={{ fontWeight: 600, marginBottom: 16, color: "#fff" }}>Penjualan 7 Hari Terakhir</div>
              <ResponsiveContainer width="100%" height={200}>
                <BarChart data={mingguan} barSize={32}>
                  <XAxis dataKey="tanggal" tickFormatter={fmtDate} tick={{ fill: "#5A7A9A", fontSize: 12 }} axisLine={false} tickLine={false} />
                  <YAxis tick={{ fill: "#5A7A9A", fontSize: 12 }} axisLine={false} tickLine={false} />
                  <Tooltip contentStyle={{ background: "#1A2535", border: "1px solid #1E2A3D", borderRadius: 8, color: "#E8EDF5" }} formatter={(v, n) => [n === "total_tabung" ? `${v} tabung` : `Rp ${fmt(v)}`, n === "total_tabung" ? "Terjual" : "Omset"]} labelFormatter={fmtDate} />
                  <Bar dataKey="total_tabung" radius={[6, 6, 0, 0]}>
                    {mingguan.map((_, i) => <Cell key={i} fill={i === mingguan.length - 1 ? "#00C896" : "#1E3A4D"} />)}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        )}

        {/* TRANSAKSI */}
        {tab === "Transaksi" && (
          <div style={{ background: "#0F1624", border: "1px solid #1E2A3D", borderRadius: 14, overflow: "hidden" }}>
            <div style={{ padding: "16px 20px", borderBottom: "1px solid #1E2A3D", fontWeight: 600, color: "#fff" }}>Riwayat Transaksi</div>
            <div style={{ overflowX: "auto" }}>
              <table style={{ width: "100%", borderCollapse: "collapse" }}>
                <thead>
                  <tr style={{ background: "#0A0F1A" }}>
                    {["Tanggal", "Pembeli", "Jumlah", "Total", "Status", "Catatan"].map(h => (
                      <th key={h} style={{ padding: "10px 16px", textAlign: "left", fontSize: 12, color: "#5A7A9A", fontWeight: 500, textTransform: "uppercase", letterSpacing: "0.05em" }}>{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {transaksi.map(t => (
                    <tr key={t.id} style={{ borderTop: "1px solid #1E2A3D" }}>
                      <td style={{ padding: "12px 16px", fontSize: 13, color: "#8A9BAE" }}>{fmtDate(t.tanggal)}</td>
                      <td style={{ padding: "12px 16px", fontSize: 13, color: "#E8EDF5" }}>{t.nama_pembeli || "-"}</td>
                      <td style={{ padding: "12px 16px", fontSize: 13, color: "#E8EDF5" }}>{t.jumlah} tabung</td>
                      <td style={{ padding: "12px 16px", fontSize: 13, color: "#F4A261", fontWeight: 600 }}>Rp {fmt(t.total)}</td>
                      <td style={{ padding: "12px 16px" }}>
                        <span style={{ background: statusColor(t.status_bayar) + "22", color: statusColor(t.status_bayar), padding: "3px 10px", borderRadius: 99, fontSize: 12, fontWeight: 500 }}>{t.status_bayar}</span>
                      </td>
                      <td style={{ padding: "12px 16px", fontSize: 12, color: "#5A7A9A" }}>{t.catatan || "-"}</td>
                    </tr>
                  ))}
                  {transaksi.length === 0 && <tr><td colSpan={6} style={{ padding: 32, textAlign: "center", color: "#5A7A9A" }}>Belum ada transaksi</td></tr>}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* HUTANG */}
        {tab === "Hutang" && (
          <div style={{ background: "#0F1624", border: "1px solid #1E2A3D", borderRadius: 14, overflow: "hidden" }}>
            <div style={{ padding: "16px 20px", borderBottom: "1px solid #1E2A3D", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
              <span style={{ fontWeight: 600, color: "#fff" }}>Daftar Hutang & DP</span>
              <span style={{ background: "#FF6B6B22", color: "#FF6B6B", padding: "4px 12px", borderRadius: 99, fontSize: 13, fontWeight: 600 }}>
                Total: Rp {fmt(hutang.reduce((a, h) => a + h.sisa_tagihan, 0))}
              </span>
            </div>
            <div style={{ overflowX: "auto" }}>
              <table style={{ width: "100%", borderCollapse: "collapse" }}>
                <thead>
                  <tr style={{ background: "#0A0F1A" }}>
                    {["Tanggal", "Pembeli", "Jumlah", "Total", "Dibayar", "Sisa", "Status", "Aksi"].map(h => (
                      <th key={h} style={{ padding: "10px 16px", textAlign: "left", fontSize: 12, color: "#5A7A9A", fontWeight: 500, textTransform: "uppercase", letterSpacing: "0.05em" }}>{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {hutang.map(h => (
                    <tr key={h.id} style={{ borderTop: "1px solid #1E2A3D" }}>
                      <td style={{ padding: "12px 16px", fontSize: 13, color: "#8A9BAE" }}>{fmtDate(h.tanggal)}</td>
                      <td style={{ padding: "12px 16px", fontSize: 13, color: "#E8EDF5" }}>{h.nama_pembeli || "-"}</td>
                      <td style={{ padding: "12px 16px", fontSize: 13, color: "#E8EDF5" }}>{h.jumlah} tabung</td>
                      <td style={{ padding: "12px 16px", fontSize: 13, color: "#F4A261" }}>Rp {fmt(h.total)}</td>
                      <td style={{ padding: "12px 16px", fontSize: 13, color: "#00C896" }}>Rp {fmt(h.jumlah_dibayar)}</td>
                      <td style={{ padding: "12px 16px", fontSize: 13, color: "#FF6B6B", fontWeight: 600 }}>Rp {fmt(h.sisa_tagihan)}</td>
                      <td style={{ padding: "12px 16px" }}>
                        <span style={{ background: statusColor(h.status_bayar) + "22", color: statusColor(h.status_bayar), padding: "3px 10px", borderRadius: 99, fontSize: 12 }}>{h.status_bayar}</span>
                      </td>
                      <td style={{ padding: "12px 16px" }}>
                        <button onClick={() => lunasin(h.id, h.total)} style={{ background: "#00C89622", color: "#00C896", border: "1px solid #00C89644", padding: "5px 12px", borderRadius: 8, fontSize: 12, cursor: "pointer", fontFamily: "'DM Sans', sans-serif" }}>Lunas</button>
                      </td>
                    </tr>
                  ))}
                  {hutang.length === 0 && <tr><td colSpan={8} style={{ padding: 32, textAlign: "center", color: "#5A7A9A" }}>Tidak ada hutang 🎉</td></tr>}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* INPUT */}
        {tab === "Input" && (
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}>
            {msg && <div style={{ gridColumn: "1/-1", background: "#00C89622", border: "1px solid #00C896", borderRadius: 10, padding: "12px 16px", color: "#00C896", fontWeight: 500 }}>{msg}</div>}

            {/* Form Stok */}
            <div style={{ background: "#0F1624", border: "1px solid #1E2A3D", borderRadius: 14, padding: 20 }}>
              <div style={{ fontWeight: 600, color: "#fff", marginBottom: 16 }}>📦 Input Stok Pagi</div>
              <form onSubmit={submitStok}>
                {[
                  { label: "Tanggal", key: "tanggal", type: "date" },
                  { label: "Stok Awal (tabung)", key: "stok_awal", type: "number", placeholder: "contoh: 50" },
                ].map(f => (
                  <div key={f.key} style={{ marginBottom: 14 }}>
                    <label style={{ display: "block", fontSize: 13, color: "#8A9BAE", marginBottom: 6 }}>{f.label}</label>
                    <input type={f.type} placeholder={f.placeholder} value={stokForm[f.key]} onChange={e => setStokForm({ ...stokForm, [f.key]: e.target.value })}
                      style={{ width: "100%", background: "#0A0F1A", border: "1px solid #1E2A3D", borderRadius: 8, padding: "10px 12px", color: "#E8EDF5", fontFamily: "'DM Sans', sans-serif", fontSize: 14, boxSizing: "border-box" }} required />
                  </div>
                ))}
                <button type="submit" style={{ width: "100%", background: "#00C896", border: "none", borderRadius: 10, padding: "12px", color: "#0A0F1A", fontWeight: 700, fontSize: 14, cursor: "pointer", fontFamily: "'DM Sans', sans-serif" }}>Simpan Stok</button>
              </form>
            </div>

            {/* Form Penjualan */}
            <div style={{ background: "#0F1624", border: "1px solid #1E2A3D", borderRadius: 14, padding: 20 }}>
              <div style={{ fontWeight: 600, color: "#fff", marginBottom: 16 }}>🫙 Input Penjualan</div>
              <form onSubmit={submitPenjualan}>
                {[
                  { label: "Tanggal", key: "tanggal", type: "date" },
                  { label: "Jumlah Tabung", key: "jumlah", type: "number", placeholder: "contoh: 5" },
                  { label: "Nama Pembeli", key: "nama_pembeli", type: "text", placeholder: "opsional" },
                  { label: "Catatan", key: "catatan", type: "text", placeholder: "opsional" },
                ].map(f => (
                  <div key={f.key} style={{ marginBottom: 12 }}>
                    <label style={{ display: "block", fontSize: 13, color: "#8A9BAE", marginBottom: 6 }}>{f.label}</label>
                    <input type={f.type} placeholder={f.placeholder} value={form[f.key]} onChange={e => setForm({ ...form, [f.key]: e.target.value })}
                      style={{ width: "100%", background: "#0A0F1A", border: "1px solid #1E2A3D", borderRadius: 8, padding: "10px 12px", color: "#E8EDF5", fontFamily: "'DM Sans', sans-serif", fontSize: 14, boxSizing: "border-box" }}
                      required={["tanggal", "jumlah"].includes(f.key)} />
                  </div>
                ))}
                <div style={{ marginBottom: 12 }}>
                  <label style={{ display: "block", fontSize: 13, color: "#8A9BAE", marginBottom: 6 }}>Status Pembayaran</label>
                  <select value={form.status_bayar} onChange={e => setForm({ ...form, status_bayar: e.target.value })}
                    style={{ width: "100%", background: "#0A0F1A", border: "1px solid #1E2A3D", borderRadius: 8, padding: "10px 12px", color: "#E8EDF5", fontFamily: "'DM Sans', sans-serif", fontSize: 14 }}>
                    <option>Lunas</option>
                    <option>Hutang</option>
                    <option>DP</option>
                  </select>
                </div>
                {form.status_bayar === "DP" && (
                  <div style={{ marginBottom: 12 }}>
                    <label style={{ display: "block", fontSize: 13, color: "#8A9BAE", marginBottom: 6 }}>Jumlah Dibayar (Rp)</label>
                    <input type="number" placeholder="contoh: 50000" value={form.jumlah_dibayar} onChange={e => setForm({ ...form, jumlah_dibayar: e.target.value })}
                      style={{ width: "100%", background: "#0A0F1A", border: "1px solid #1E2A3D", borderRadius: 8, padding: "10px 12px", color: "#E8EDF5", fontFamily: "'DM Sans', sans-serif", fontSize: 14, boxSizing: "border-box" }} />
                  </div>
                )}
                <button type="submit" style={{ width: "100%", background: "#00C896", border: "none", borderRadius: 10, padding: "12px", color: "#0A0F1A", fontWeight: 700, fontSize: 14, cursor: "pointer", fontFamily: "'DM Sans', sans-serif" }}>Simpan Transaksi</button>
              </form>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
